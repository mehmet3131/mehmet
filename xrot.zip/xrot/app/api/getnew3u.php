<?php

$v = base64_decode($_GET['v']);
$postd = '{"x":"YW5kcm9pZDqk/WPgTuuTFwA3MceQXH8rEZgdQ+yzsot11RMv9vmsvYDR8I0zwzCGM+A9T5IHLKJ8xqix2kITG23ipgqVz5VU1Pzd2QYYZkZaGGUlUHfAKTfSmq2Pmf5EX25oZTzECjymS/9oFNWmjA1dPHk1lANDVxxjvhr9vNnYXYvE2y7rdIrDakSUrTnpbfDZ0i64MsZOrOFGPzzSMrEHPjs8M8s9E/ABSiUJDvplbmpJ4okx1R7J8Rq4vNAe2nK3hJjlb8SB9N71RYpw4WzpHmsIiKTSM4C2Q9LfRfbYTwQrN0SJT+1fjVR5unzF+VcRNd37nvxLrS6+rHsnKQ3ENm+P/xlky8RV2rJzxZmBGqmmVXJbE8K/5d1CwCcPkLqA/fRODeQDDIMQO+eOjrKEIo6twX93D3HxTass5a9vrUh2dE3yHZv5q3LvQ75UGHXa6oLeNPhqrYnB9nFGqpOB88+nqN1Svc4N7NzbB57kqtrfGlEKTU7EZDLlfgZPXJXn3K4KVXIaaLmdSHBplfVrmt+Q9Mh8Ut/USAaZpUPEKWf6SKBSSj5XPlL6siCm6Jv6q/qJ7ljJE2dnWkMh5zb8kVUSKfvLxF504sxHggzWo756lc9NLEuiejZRR3PzdEpoufV+uyrAg+Hw5Tw8u7BwnC7J2Nyt60Fypzigl94piG3EUqp7e1Nl0YqceRLNmR7+bT0Yn8I+eItqqaoLPybhNS6GvJr2l1S/xGJEQTtpllhV7P69rzu0mFKOf6FVyFAXiCwYKNHtkBHuE3cQrSzuY//tvV0c0i33R3BjuJL56Xiq20khCl/IwcZYfGhj8dY2QB0C88+4aZcgYL/YXRr4sQ+TaDSfGfa1VfM/QozNbPHRRrtQbcr1BdQy6uJhR1QYwN/pxzeSMOepsorfxOsaJG90Jk9vrzPaX1xxkg0gagSsdcPfFd0aM89oKGGLNrcqzrtsGMomRejYGjSn5XxBhVYGSCqzWqqEzWzX36tKwI+Lkw9IFJkzdI7Nq6c5gEUgPUWBH6NQrz1UVIzX80Q83dgCnYr/PhGpS5j+cjAIpLM54UWUT8nJOOGPHy0Y8pAbQU5+wixuh1vV7BfBZB1G0+WdfuctD1DkhGKCxepLl1Qm64JgRBLFkAq4a9GeM92ydctDn2KXoFKLEDolFfAUfkIEj4aPqdwB1gzcYifYKw5T84NG7vmsk6O+dZqFIb+7VYhRQJX1/ncWBM58KJBOfqTYmur6ZHM/P0oxx518vPSWR3zGJNfDLpd5ng5Q0Azso9S4d2hplCC13L7VkWogR56W3WQhD/VD4PVkJ0SOQ8zyCa9lgA2DHwd8YW4lmIQohmRflty8AwE0v+dF/E++tlmKApThky/KRwXL2huuWCd7RhzX/8YgY6UuuzjHHuXBR11xksIeEVXayanPJBOX3B/07A+4fQoSQ5FYIEubcWCEIIpiWOirDuTZ5R7DcJgb9ZPLFyD9EyWRI80gsOgz9lzxN9tCSZPo+HYCxGkG3dq7UQN/RXy6MX/KmNU+qgNLCVqq+yyh2pENdjeNbS4+/uhN6jE8Wi6vNUPmjm8bzqt8jDA2yjgQxOZVkfbulrVsAeSNsu5XpNE5fpAUVhRcjz7L4aZ9+ArU8ISlAeqVSRwkrl56OEJjYsnuINeI/nR6JUMxwso/I8rApZqHjZV2vfJcTA50EgGDslbsYHx/upW8r0U7763ubvacKm2nWgpTumz5eLyCkEl4ZiKTEXVMhb4uoCNGuEGB32PP24cCdcdRs0ad8ZvZ3kfUVgbmyHgwOgygtSqY+yGAQ2TSv8LbUwL67e9wEm/ML+ZmnzgJXKmvrbJVga7fGf04cM5+fs3d++LfklRR99otOUCuFDslV7z4MyK3SiieN0FajJUeYeCq2wZc2uuFfI0QgHBMVuZEXR4M2qwWiSk8JllhEr3nvrq29pVwjXXU/H1HvDgQFltDKq9cNtBltcRRJro/+dlHHgQn4fuFqQLG3mK5q8OHiz9+/KTYG7/xGZVjsNfBSFNC5+qUjKAG41PepTo7WbQSBVBRvwrV2qnC1kwCkxrt4wrU+GXl4b9f/rX52pap4sPuq+Gz1nBike04ZYAROhyAN8N9fuoYoNKJo6AWC7ETFeH5SP+y2nR8SxMZcPp+lO4WMGT0SlsYSbYAUdj6lfmVGE/zLCJuEh9qRmJWPoUywDJwZsRexc4zOsC/gk2NoETo6mSj3OteOK8XdfoVI4i82livNMAzV4RL0FvkR3P5aVDvqxv78lw9iXMBBaI7FBw7oadLdpws54dm0SEYC2srXa/eKWhZqo/R9zg4tYcQoGgofplwlg6EydV+N16sCGYIvS/Byihyc38dvmnhIbhjsXr234qRHB1++1TI0dhKGcFUlQrmRJjMGWxIZG3bZf4FtdNWGmomQludptXBgtSnX2JoQ6sT5rzBxQAQ0Y/Ns740i+Of"}';
//getsigned
$keyurl = 'https://www.rokkr.net/api/box/ping';
$options = array(
'header'=>array(
'user-agent'=>'Rokkr/1.7.2 (android)',
'content-type'=>'application/json',
),
'post'=>$postd,
);
$left = '';
$right = '';
$getkey = json_decode($this->get_contents($left,$right,$keyurl,$options), true);

//$this->print_pre($getkey);




$postdata = '{"language":"tr","region":"TR","url":"'.$v.'"}';

//playurl
$url = 'https://www.oha.to/oha-tv-resolver/resolve.watched';
$options = array(
'header'=>array(
    'user-agent'=>'Rokkr/1.7.2 (android)',
    'content-type'=>'application/json', 
'watched-sig'=>$getkey['response']['signed'],
//'watched-sig'=>'eyJkYXRhIjoie1widGltZVwiOjE2NTA1MDAwMTc3MDgsXCJ2YWxpZFVudGlsXCI6MTY1MDUwMTIxNzcwOCxcInVzZXJcIjpcIkZGSmQ3dDhCMnlwSFN3ek9kK3RjdGVoYmNEOXpPY0pSaHp6UmQxR3BTeWs9XCIsXCJzdGF0dXNcIjpcImd1ZXN0XCIsXCJ2ZXJpZmllZFwiOmZhbHNlLFwiaXBzXCI6W1wiMTc2Ljg4LjQ0LjIwXCJdLFwiZXJyb3JcIjpudWxsLFwiYXBwXCI6e1wibmFtZVwiOlwicm9ra3JcIixcInZlcnNpb25cIjpcIjEuNy4yXCIsXCJwbGF0Zm9ybVwiOlwiYW5kcm9pZFwiLFwib2tcIjp0cnVlfX0iLCJzaWduYXR1cmUiOiJocGUwU2F5K25lRDBFdTZPV0xJUlQ2NVJzWjQzRFl0QS9oT2VYSmhOYWlmeVp2OU5wbGVpQW53Z1g1eWNML0JhM2pzc3EvbWtpby9yeGZhQnU3Vm9tNEEwWEQycHJUdXp2L0JrNmFydGxxNGtkdmVqR0pUMjRDOEF6bkdTNVRnOWtIQTVKNDFIVFlJVFVtUW5RNkRXRE0wdm1qaEJKNWpndEtZWDUxZTBsdlk9In0=',
),
'post'=>$postdata,
);
$left = '';
$right = '';
$getply = json_decode($this->get_contents($left,$right,$url,$options), true);


//$this->redirect('https://hworx.pw/sbots/rokm3u/?v='.base64_encode($getply[0]['url']));

//$this->redirect(''.$getply[0]['url']);

//echo $getply[0]["url"];

//$this->print_pre($getply);


$urlx = $getply[0]['url'];
$options = array(
'header'=>array(
    'Icy-MetaData'=>'1',
    'user-agent'=>'Rokkr/1.7.2 (android)',
)
);
$left = '';
$right = '';
$getts = $this->get_contents($left,$right,$urlx,$options);


$newlink = str_replace('index.m3u8', '', $getply[0]['url']);

//$getts = str_replace(',', ','.$newlink, $getts);


$left = ',';
$right = '.ts';
$getzz = $this->get_contents($left,$right,$getts);

//$this->print_pre($getzz);

foreach($getzz as $key => $val){
   $getts = str_replace($val, DOMAIN.'/tsrok/?v='.$newlink.$val, $getts);
}

header('content-type: text/plain');
header('access-control-allow-origin: *');
 
 echo $getts;    


?>


