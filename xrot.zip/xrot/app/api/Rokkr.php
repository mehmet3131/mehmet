<?php



$postd = '{"x":"YW5kcm9pZDpR/BnaNJwveiFnvkfpUkZcmad4TAOCUvGyJj54nHkzDyAY/6QLODrxk62EA2a5IcYXR7HrM6/EBBkUyUxAgMK4RzZn8u0djZhaj5iC4dfzlrH1p/FycWBp7KhxMkl2UHN03lb7XfvmvORFs0xJhSQx9+oSWWtpMll0ASJw+XqGQhuEQwA4zL/mfmpVMXl+1I9SsyuwZTCWb8UCPzM7XR+kO5j5k588PltlBAKX82psfMpNw9SgVdYU5aYxsRcol5oKXNTGSO6zIUeJZGf9NcWPSs1Tp/AAl3zPzGjxsGgX0iGwQ9B2a54mTOHsTd0l+CZVPB89j2ZVvyIXTXbwpb2e+QxyYuz8UZtNtcsjmL6NGLQhpXlJyHDkiIMj/OmH/dq3DGWn4c3XkH0xpUvZwr1pinyhiF5bfmQzendBUfcSDhBWc+YMTjvwIZJISgQ0bRAIQyg+CqWRJVBIsRa0FSHipN3fGqcSWpOHtSBLPzk7/f1AR4M6o8W4ErGBAH8a67mrfsPP4l4L/h5ZROmFhYRIlKZxYACoWYnq71fPdZ7E8sm+YgnSrn5Fl9PbS553blrBwsSqJC/Ku8DuAHm+vDiJZYCN0MX0KTfMu/TNBvUADZfJJzysAw29xwS6s0T6BjxNCjbLHbz7ef/9C9vPregoJI12Na5Lr0UbiTZgtk4QVMaFL/2aGIsnHw55FGYr6P1sZC7GM6K/fzS1r5rOaAqhojm2PhNct5wjUfy4XuaNLBmww3exm/FGpWgCgghYM2NCYBkoDX/HvzJf6cTo1Zo0EANIliHHnU3Rh5Fxfs4ckUR/zXEm4Z0m9kdiAGLMR+0j68j92YmuUZFvlWWU7qyBO+ZKrXR/0Uj16ZjWrx5vrMMscVsPG6zojW2FTQCb+R+culKq9GKn0YIogOqo/Qh5jjeG/ohdMJ3tNWZcyQ3p1M2YbxaIM/Nv1wPGMeH+oi3Uif56CuSpzpEiYO0m4lMa5cBl/+UruM9vX2UObGu1nMWXnYjmnf+LsN6aA4+rF3F6UXvsLXz8/YqOJVwOBXYxiavz7mmbgpndCvpkTL0q3ocX5dBryrm0HI9wo5QDBH5prdOSMloxDayA4OgG0Ucdn0tHFgG/pgsrc2/FKuFMyXWBtD6jQP/Jp/jJKGLwmX/uOtayv0o7IeiijxMZ37pQCog6VY3NwH0E5dD8+b1tSS8BSvjsiif9rlVEz+t5w1DRQdgv4hAREPxnAR55Jdph7Uwx4CE+O95j/XEArn30glrh3diRj4UDJRZivJp8mI+QGmhCAQHUdppzaVX9zgU3gxzHnM5sWH83y0XLUg0KDls71JuOJ49C6Z9Ehp2zfcubOBATDjXW2FmUoe3eAyxOgQUpcW4zWnAkO/ux8dARzQBJkOjBjC62a45MrZzFBIL2RaPPJq//gQ0t78MlisQiYJ/wLqTo2pGsA5iyiE+vCOF730RsYENh7+Sc/eXSfKSVww9bMhW+FLcIPsMczOGPeXFbhr1A3du/93W7qVLqVjwpvlqHGP7q9uu8u6rrgqLTbAIUhwE54NChXp0Kdr7aYXtpgGkxTanLFvVTB56siVni0mwQDJXBDY4dq3sFC+r8Zt3kWjHNUjNWSSSU/gtQsP/ki2jjiZzfHBJmobjoYL/mOKBtawnB8sfA8WW5jcwLYwOBfkg8lAekTB9TM+mMHwdsimwcykGb2zo4APSCdbpTLOl5LCfJX9U2JrdwEduE3hJFOqPTVcRrRofFTxoDOtrocNgDz6um03DbAGEpn72bFXhd8oxTFDkdcFLYlrdTMlAYz/vZwX4gI6pjPS65EHy6csoKUHG7vnnRcQE4Ex8FFoLzKBUUYtC3l0dqSRknnekT8Cv4+RaiBm+Aj8385qis90NZ9kyiLKaDUKYYc+mACWfkGjCgGAOqEb5Z1tV9Is8qBCuZr07izdZB2e0XXhmlBcWnX4F9sW/2PGAQ5vKytkN64edQOiu3cY9TTg7iMXxm5ezdsIL1Yct3YCr/YfB18RE93EdcBfW9Z9dmiz70k50RM4kkNgX53y5OAVmqCGGSxIhqBQlap0b72o4U3yuXxoGqblHczDEO4/Q4lhEIu1jRZmy2Q193AmTXEGhx3Bvyuaj0jcpAZBvghfWAxr7ihmMjUk+m7bc/sEJQRgQRBKdgz2gYYoipjiuwZTqU1WlSpDrzsj5Bu60TWlnbbJm2CCTp2MjOO81QTdyWVOwBmpM/IINWYWY5yPY+ipvE/UM8ieCIVss+hLcnCj1tmzea5NYa9z7TsxTOAeUVCIdTbxJfO6JjXdd1JDMI/OLxDBP4N14Qu5ExTp2C8YC92QLghKLD8XeJBIClczuIqu1Z4zfJwYWF1xDGN52gVBKQlZsBm8hnPY3R70guVd9GZSJGoZq2ENANzNxhzR3eaT2sQVIGzlo9rUruqtyg/4Y="}';
//getsigned
$keyurl = 'https://www.rokkr.net/api/box/ping';
$options = array(
'header'=>array(
'user-agent'=>'Rokkr/1.7.2 (android)',
'content-type'=>'application/json',
),
'post'=>$postd,
);
$left = '';
$right = '';
$getkey = json_decode($this->get_contents($left,$right,$keyurl,$options), true);



//echo $options['post'];
//$this->print_pre($getkey);






$postdata = '{"language":"tr","region":"TR","id":"","adult":true,"search":"","sort":"trending-region","filter":{"group":"Turkey"},"cursor":null,"rootId":""}';


//json
$url = 'https://www.oha.to/oha-tv-index/directory.watched';
$options = array(
'header'=>array(
    'user-agent'=>'Rokkr/1.7.2 (android)',
    'content-type'=>'application/json',
'watched-sig'=>$getkey['response']['signed'],
),
'post'=>$postdata,
);

$left = '';
$right = '';

$getjson = $this->get_contents($left,$right,$url,$options);

$getjs = json_decode($getjson, true);

//$this->print_pre($getjs);


/*items [url] => https://www.oha.to/oha-tv/play/cf03bea95b22550650b6f03582ba
[name] => BEIN SPORTS 1 FHD |E
[group] => Turkey
[logo] => https://www.oha.to/logo?c=3106355112.png */















/*
//playurl
$url = 'https://www.oha.to/oha-tv-index/directory.watched';
$options = array(
'header'=>array(
'watched-sig'=>$getkey['response']['signed'],
),
'post'=>array(
'language'=>'tr',
'region'=>'TR',
'url'=>'',
)
);
$left = '';
$right = '';
$getply = json_decode($this->get_contents($left,$right,$url,$options), true);

//$this->print_pre($get);
*/



?>







<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="color-scheme" content="dark" />
    <title>Rokkr</title>
    <script type="module" src="https://cdn.jsdelivr.net/npm/@ionic/core/dist/ionic/ionic.esm.js"></script>
    <script nomodule src="https://cdn.jsdelivr.net/npm/@ionic/core/dist/ionic/ionic.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@ionic/core/css/ionic.bundle.css" />
    <style>

@import url('https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,500&display=swap');
     
    :root {
--ion-text-color:  #fff;
--ion-font-family: "Jost";
 --ion-background-color: #171717; 
    }
*{
    user-select: none!important;
}
 

    ion-title {
        font-size: 24px;
        font-weight:800;
    }
ion-item {
        --background: linear-gradient( 89.7deg,  rgba(0,0,0,1) -10.7%, rgba(53,92,125,1) 88.8% );
        margin-bottom: 1vh;
        border-radius: 5px;
        transition: 1000ms linear,

    }
ion-item:hover {
        --background: linear-gradient( 270deg,  rgba(0,0,0,1) -10.7%, rgba(53,92,125,1) 88.8% );
        margin-bottom: 1vh;
        border-radius: 5px;
    }


    h2{
        font-style:italic;
    }

    h3{
        color: #ccc;
    }
    
ion-searchbar {
      --color: white; /* Arama çubuğu yazı rengini beyaz olarak ayarlar */
    }




    </style>
  </head>
  <body>
  <ion-app>
    <ion-header translucent>
      <ion-toolbar>
        <ion-title>Rokkr / Kanallar</ion-title>
        <ion-searchbar placeholder="Kanal ara" color="transparent"></ion-searchbar>
      </ion-toolbar>
    </ion-header>

    <ion-content fullscreen>
      <ion-list id="channel-list">
      
      <?php 
        
        $new = array();

        for($i = 0; count($getjs['items']) > $i; $i++){

if(!empty($getjs['items'][$i])){


$new[$i]['url'] = $getjs['items'][$i]['url'];
$new[$i]['name'] = $getjs['items'][$i]['name'];
$new[$i]['group'] = $getjs['items'][$i]['group'];
$new[$i]['logo'] = $getjs['items'][$i]['logo'];


if(empty($new[$i]['logo'])){
    $new[$i]['logo'] = 'https://apkresult.com/Logos/rokkr-premium-apkresult.jpg';
}




        
        
        
        
        ?>
      <div class="back">
          <ion-item onclick="location.href='<?=DOMAIN?>/play/?v=<?=base64_encode($new[$i]['url'])?>'">
            <ion-avatar slot="start">
              <img src="https://dl.memuplay.com/new_market/img/net.rokkr.app.icon.2021-05-05-21-14-47.png" />
            </ion-avatar>
            <ion-label>
              <h2><?=$new[$i]['name']?></h2>
              <h3><?=$new[$i]['group']?></h3>
            </ion-label>
          </ion-item>
</div>
      <?php

}
}

?>

        
        <!-- Diğer kanallar burada yer alacak -->

      </ion-list>
    </ion-content>
  </ion-app>

  <script>
    const searchbar = document.querySelector('ion-searchbar');
    const channelList = document.getElementById('channel-list');

    searchbar.addEventListener('ionInput', handleSearch);

    function handleSearch(event) {
      const searchText = event.target.value.toLowerCase();
      const items = channelList.querySelectorAll('.back');
      
      items.forEach(item => {
        const title = item.querySelector('h2').textContent.toLowerCase();
        if (title.includes(searchText)) {
          item.style.display = 'block';
        } else {
          item.style.display = 'none';
        }
      });
    }
  </script>
</body>
</html>